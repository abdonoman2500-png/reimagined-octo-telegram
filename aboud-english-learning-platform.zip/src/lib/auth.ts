import { cookies } from "next/headers";
import jwt from "jsonwebtoken";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

const JWT_SECRET = process.env.JWT_SECRET || "aboud_english_platform_secure_jwt_secret_key_2025";

export interface SessionUser {
  id: number;
  name: string;
  email: string;
  role: "student" | "teacher" | "admin";
  currentLevel: string;
  xp: number;
  streakDays: number;
}

export function createToken(payload: SessionUser): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "7d" });
}

export function verifyToken(token: string): SessionUser | null {
  try {
    return jwt.verify(token, JWT_SECRET) as SessionUser;
  } catch {
    return null;
  }
}

export async function getCurrentUser(): Promise<SessionUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get("auth_token")?.value;
  if (!token) return null;

  const decoded = verifyToken(token);
  if (!decoded) return null;

  // Refresh latest user record from DB
  const [userRecord] = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      role: users.role,
      currentLevel: users.currentLevel,
      xp: users.xp,
      streakDays: users.streakDays,
    })
    .from(users)
    .where(eq(users.id, decoded.id))
    .limit(1);

  if (!userRecord) return null;

  return {
    id: userRecord.id,
    name: userRecord.name,
    email: userRecord.email,
    role: userRecord.role as "student" | "teacher" | "admin",
    currentLevel: userRecord.currentLevel,
    xp: userRecord.xp,
    streakDays: userRecord.streakDays,
  };
}
