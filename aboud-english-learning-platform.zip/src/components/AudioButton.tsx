"use client";

import React, { useState } from "react";
import { Volume2, Volume1, Loader2 } from "lucide-react";
import { playEnglishText, stopSpeaking } from "@/lib/speech";

interface AudioButtonProps {
  text: string;
  size?: "sm" | "md" | "lg";
  variant?: "primary" | "secondary" | "minimal";
  speed?: number; // 0.9 default, 0.6 for slow
  showSlowToggle?: boolean;
  className?: string;
}

export function AudioButton({
  text,
  size = "md",
  variant = "primary",
  speed = 0.85,
  showSlowToggle = false,
  className = "",
}: AudioButtonProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSpeed, setCurrentSpeed] = useState(speed);

  const handlePlay = async (rateToUse: number) => {
    if (isPlaying) {
      stopSpeaking();
      setIsPlaying(false);
      return;
    }

    setIsPlaying(true);
    try {
      await playEnglishText(text, rateToUse);
    } finally {
      setIsPlaying(false);
    }
  };

  const sizeClasses = {
    sm: "p-1.5 text-xs rounded-lg",
    md: "px-3 py-1.5 text-sm rounded-xl",
    lg: "px-4 py-2.5 text-base rounded-2xl",
  };

  const variantClasses = {
    primary:
      "bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 hover:border-indigo-400 active:scale-95",
    secondary:
      "bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 active:scale-95",
    minimal:
      "hover:bg-slate-800 text-slate-300 hover:text-indigo-400 p-1.5 rounded-lg active:scale-95",
  };

  return (
    <div className={`inline-flex items-center gap-1.5 ${className}`}>
      <button
        type="button"
        onClick={() => handlePlay(currentSpeed)}
        title="استمع للنطق"
        className={`flex items-center gap-1.5 font-medium transition duration-150 cursor-pointer ${sizeClasses[size]} ${variantClasses[variant]}`}
      >
        {isPlaying ? (
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-3 bg-indigo-400 animate-pulse rounded-full"></span>
            <span className="w-1.5 h-4 bg-indigo-300 animate-pulse delay-75 rounded-full"></span>
            <span className="w-1.5 h-2 bg-indigo-400 animate-pulse delay-150 rounded-full"></span>
          </span>
        ) : (
          <Volume2 className={size === "sm" ? "w-3.5 h-3.5" : size === "lg" ? "w-5 h-5" : "w-4 h-4"} />
        )}
        <span className="text-xs">استمع</span>
      </button>

      {showSlowToggle && (
        <button
          type="button"
          onClick={() => handlePlay(0.55)}
          title="استمع ببطء شديد للمبتدئين"
          className="px-2 py-1 text-[11px] rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-300 border border-slate-700/60 transition"
        >
          بطيء 🐢
        </button>
      )}
    </div>
  );
}
