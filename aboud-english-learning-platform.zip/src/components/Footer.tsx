import React from "react";
import Link from "next/link";
import { GraduationCap, Heart, Shield, HelpCircle, Mail, Globe, CheckCircle } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand & Mission */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
                <GraduationCap className="w-6 h-6" />
              </div>
              <span className="font-bold text-lg text-white">منصة عبود التعليمية</span>
            </div>
            <p className="text-xs leading-relaxed text-slate-400">
              المنصة العربية المتكاملة لتعلّم اللغة الإنجليزية من الصفر حتى الإتقان. شروحات مبسطة باللغة العربية، نطق صوتي دقيق، اختبارات تفاعلية، وشهادات إتمام.
            </p>
            <div className="flex items-center gap-2 text-xs text-indigo-400">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>مناهج متوافقة مع الإطار الأوروبي المشترك CEFR</span>
            </div>
          </div>

          {/* Quick Learning Paths */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">المستويات التعليمية</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/alphabet" className="hover:text-indigo-400 transition">
                  Pre-A1: الحروف والأصوات من الصفر
                </Link>
              </li>
              <li>
                <Link href="/grammar" className="hover:text-indigo-400 transition">
                  A1 - A2: المبتدئ وتكوين الجمل والماضي
                </Link>
              </li>
              <li>
                <Link href="/conversations" className="hover:text-indigo-400 transition">
                  B1 - B2: المحادثات اليومية والقواعد المتقدمة
                </Link>
              </li>
              <li>
                <Link href="/reading-writing" className="hover:text-indigo-400 transition">
                  C1 - C2: الطلاقة، الأمثال، والكتابة الاحترافية
                </Link>
              </li>
              <li>
                <Link href="/placement-test" className="text-indigo-400 hover:underline">
                  اختبار تحديد المستوى المجاني ←
                </Link>
              </li>
            </ul>
          </div>

          {/* Learning Tools */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">الأقسام التفاعلية</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/vocabulary" className="hover:text-indigo-400 transition">
                  القاموس وقوائم الكلمات
                </Link>
              </li>
              <li>
                <Link href="/listening" className="hover:text-indigo-400 transition">
                  تمارين الاستماع والنطق الصوتي
                </Link>
              </li>
              <li>
                <Link href="/quizzes" className="hover:text-indigo-400 transition">
                  الاختبارات والألعاب التعليمية
                </Link>
              </li>
              <li>
                <Link href="/favorites" className="hover:text-indigo-400 transition">
                  مراجعة البطاقات والكلمات المحفوظة
                </Link>
              </li>
              <li>
                <Link href="/certificates" className="hover:text-indigo-400 transition">
                  التحقق من شهادات المنصة
                </Link>
              </li>
            </ul>
          </div>

          {/* Help & Policies */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">الدعم والمساعدة</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link href="/faq" className="hover:text-indigo-400 transition">
                  الأسئلة الشائعة (FAQ)
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-indigo-400 transition">
                  اتصل بنا والدعم الفني
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-indigo-400 transition">
                  سياسة الخصوصية
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-indigo-400 transition">
                  شروط الاستخدام
                </Link>
              </li>
            </ul>

            <div className="mt-4 p-3 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-400">
              <span className="block text-slate-300 font-medium mb-1">ملاحظة بشأن الشهادات:</span>
              الشهادات الصادرة هي شهادات إتمام رقمية صادرة من منصة عبود لتوثيق تقدم الطالب واجتيازه للمقررات.
            </div>
          </div>
        </div>

        <hr className="border-slate-800/80 my-8" />

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} منصة عبود لتعلّم اللغة الإنجليزية. جميع الحقوق محفوظة.</p>
          <p className="flex items-center gap-1">
            صُمم بشغف لدعم المتعلمين العرب في مسيرتهم نحو طلاقة اللغة الإنجليزية
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 inline" />
          </p>
        </div>
      </div>
    </footer>
  );
}
