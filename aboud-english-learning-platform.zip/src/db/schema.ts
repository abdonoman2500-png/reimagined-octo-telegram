import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").default("student").notNull(), // 'student' | 'teacher' | 'admin'
  avatar: text("avatar").default("/avatars/default.png"),
  currentLevel: text("current_level").default("Pre-A1").notNull(),
  xp: integer("xp").default(0).notNull(),
  streakDays: integer("streak_days").default(1).notNull(),
  lastActiveDate: timestamp("last_active_date").defaultNow(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const levels = pgTable("levels", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // 'Pre-A1', 'A1', 'A2', 'B1', 'B2', 'C1', 'C2'
  titleAr: text("title_ar").notNull(),
  titleEn: text("title_en").notNull(),
  descriptionAr: text("description_ar").notNull(),
  orderIndex: integer("order_index").notNull(),
  color: text("color").default("from-blue-600 to-indigo-600"),
  icon: text("icon").default("GraduationCap"),
});

export const units = pgTable("units", {
  id: serial("id").primaryKey(),
  levelCode: text("level_code").notNull(),
  titleAr: text("title_ar").notNull(),
  titleEn: text("title_en").notNull(),
  descriptionAr: text("description_ar"),
  orderIndex: integer("order_index").notNull(),
  icon: text("icon").default("BookOpen"),
});

export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  unitId: integer("unit_id"),
  levelCode: text("level_code").notNull(),
  category: text("category").notNull(), // 'alphabet', 'grammar', 'vocabulary', 'conversation', 'listening', 'reading'
  titleAr: text("title_ar").notNull(),
  titleEn: text("title_en").notNull(),
  descriptionAr: text("description_ar"),
  contentJson: text("content_json").notNull(),
  orderIndex: integer("order_index").notNull(),
  durationMinutes: integer("duration_minutes").default(10).notNull(),
  xpReward: integer("xp_reward").default(25).notNull(),
  isPublished: boolean("is_published").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const vocabulary = pgTable("vocabulary", {
  id: serial("id").primaryKey(),
  word: text("word").notNull(),
  phonetic: text("phonetic"),
  partOfSpeech: text("part_of_speech").default("noun"),
  translationAr: text("translation_ar").notNull(),
  levelCode: text("level_code").notNull(),
  category: text("category").notNull(),
  exampleEn: text("example_en"),
  exampleAr: text("example_ar"),
  audioUrl: text("audio_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const userFavorites = pgTable("user_favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  vocabId: integer("vocab_id").notNull().references(() => vocabulary.id, { onDelete: "cascade" }),
  mastered: boolean("mastered").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  titleAr: text("title_ar").notNull(),
  titleEn: text("title_en").notNull(),
  scenario: text("scenario").notNull(),
  levelCode: text("level_code").notNull(),
  dialogueJson: text("dialogue_json").notNull(),
  grammarNotesAr: text("grammar_notes_ar"),
  orderIndex: integer("order_index").default(0).notNull(),
});

export const quizzes = pgTable("quizzes", {
  id: serial("id").primaryKey(),
  titleAr: text("title_ar").notNull(),
  titleEn: text("title_en").notNull(),
  levelCode: text("level_code").notNull(),
  unitId: integer("unit_id"),
  lessonId: integer("lesson_id"),
  category: text("category").notNull(), // 'placement', 'unit_exam', 'grammar', 'vocabulary', 'listening', 'reading'
  passScore: integer("pass_score").default(70).notNull(),
  timeLimitMinutes: integer("time_limit_minutes").default(15).notNull(),
  xpReward: integer("xp_reward").default(50).notNull(),
  questionsJson: text("questions_json").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  lessonId: integer("lesson_id").notNull().references(() => lessons.id, { onDelete: "cascade" }),
  status: text("status").default("completed").notNull(),
  completedAt: timestamp("completed_at").defaultNow().notNull(),
});

export const quizAttempts = pgTable("quiz_attempts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  quizId: integer("quiz_id").notNull().references(() => quizzes.id, { onDelete: "cascade" }),
  score: integer("score").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  passed: boolean("passed").notNull(),
  answersJson: text("answers_json"),
  completedAt: timestamp("completed_at").defaultNow().notNull(),
});

export const certificates = pgTable("certificates", {
  id: serial("id").primaryKey(),
  certificateNumber: text("certificate_number").notNull().unique(),
  userId: integer("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  levelCode: text("level_code").notNull(),
  studentName: text("student_name").notNull(),
  score: integer("score").notNull(),
  issuedAt: timestamp("issued_at").defaultNow().notNull(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: text("status").default("unread").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
