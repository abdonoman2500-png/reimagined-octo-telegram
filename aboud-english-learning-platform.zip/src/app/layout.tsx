import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AuthProvider } from "@/context/AuthContext";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export const metadata: Metadata = {
  title: "منصة عبود لتعلّم اللغة الإنجليزية من الصفر | Aboud English",
  description: "المنصة العربية المتكاملة لتعلّم اللغة الإنجليزية من الصفر وحتى الاحتراف وفق الإطار الأوروبي CEFR. قواعد، مفردات، محادثات، نطق صوتي، واختبارات تفاعلية.",
  keywords: ["تعلم الانجليزية", "قواعد اللغة الانجليزية", "محادثات انجليزي", "منصة عبود", "نطق الانجليزية", "CEFR"],
  authors: [{ name: "الأستاذ عبود" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" className="dark">
      <body className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white antialiased flex flex-col justify-between">
        <AuthProvider>
          <Navbar />
          <main className="flex-1 w-full">{children}</main>
          <Footer />
        </AuthProvider>
      </body>
    </html>
  );
}
