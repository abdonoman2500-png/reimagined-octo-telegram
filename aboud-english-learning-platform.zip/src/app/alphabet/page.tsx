"use client";

import React, { useState } from "react";
import { AudioButton } from "@/components/AudioButton";
import { LevelBadge } from "@/components/LevelBadge";
import { playEnglishText, playSoundEffect } from "@/lib/speech";
import {
  Sparkles,
  Volume2,
  CheckCircle,
  HelpCircle,
  BookOpen,
  Award,
  Gamepad2,
  Star,
  RefreshCw,
  Lightbulb,
} from "lucide-react";

interface LetterData {
  char: string;
  lower: string;
  name: string;
  ipa: string;
  type: "vowel" | "consonant";
  word: string;
  wordAr: string;
  icon: string;
  sentence: string;
  sentenceAr: string;
  tips: string;
}

const alphabetData: LetterData[] = [
  { char: "A", lower: "a", name: "اي", ipa: "/æ/ - /eɪ/", type: "vowel", word: "Apple", wordAr: "تفاحة", icon: "🍎", sentence: "An apple a day keeps the doctor away.", sentenceAr: "تفاحة في اليوم تغنيك عن الطبيب.", tips: "حرف متحرك أساسي. يُنطق قصيراً مثل (Cat) أو طويلاً مثل (Cake)." },
  { char: "B", lower: "b", name: "بي", ipa: "/b/", type: "consonant", word: "Book", wordAr: "كتاب", icon: "📖", sentence: "I read an interesting book.", sentenceAr: "قرأت كتاباً ممتعاً.", tips: "حرف الباء مع إخراج خفيف للهواء من الشفتين." },
  { char: "C", lower: "c", name: "سي", ipa: "/k/ or /s/", type: "consonant", word: "Cat", wordAr: "قطة", icon: "🐱", sentence: "The cat is sleeping on the chair.", sentenceAr: "القطة نائمة على الكرسي.", tips: "يُنطق (س) إذا تبعه (e, i, y) مثل City. وباقي الحالات يُنطق (ك) مثل Car." },
  { char: "D", lower: "d", name: "دي", ipa: "/d/", type: "consonant", word: "Door", wordAr: "باب", icon: "🚪", sentence: "Please close the door.", sentenceAr: "من فضلك أغلق الباب.", tips: "حرف الدال الإنجليزي الواضح." },
  { char: "E", lower: "e", name: "إي", ipa: "/e/ - /iː/", type: "vowel", word: "Elephant", wordAr: "فيل", icon: "🐘", sentence: "The elephant is very big.", sentenceAr: "الفيل ضخم جداً.", tips: "حرف متحرك. قصير في Egg وطويل في Tree. صامت غالباً في نهاية الكلمة." },
  { char: "F", lower: "f", name: "إف", ipa: "/f/", type: "consonant", word: "Fish", wordAr: "سمكة", icon: "🐟", sentence: "Fish swim in the blue ocean.", sentenceAr: "الأسماك تسبح في المحيط الأزرق.", tips: "حرف الفاء، بملامسة الأسنان العلوية للشفة السفلية." },
  { char: "G", lower: "g", name: "جي", ipa: "/ɡ/ or /dʒ/", type: "consonant", word: "Giraffe", wordAr: "زرافة", icon: "🦒", sentence: "The giraffe has a tall neck.", sentenceAr: "الزرافة لها رقبة طويلة.", tips: "يُنطق جيما قاهرية (Go) أو معطشة (Gym) إذا تبعه e/i/y." },
  { char: "H", lower: "h", name: "إيتش", ipa: "/h/", type: "consonant", word: "House", wordAr: "منزل", icon: "🏠", sentence: "Our house is warm and cozy.", sentenceAr: "منزلنا دافئ ومريح.", tips: "حرف الهاء الصافي في بداية الكلمات." },
  { char: "I", lower: "i", name: "آي", ipa: "/ɪ/ - /aɪ/", type: "vowel", word: "Ice", wordAr: "ثلج", icon: "🧊", sentence: "Put some ice in the juice.", sentenceAr: "ضع بعض الثلج في العصير.", tips: "حرف متحرك مثل الكسرة في Sit أو الآي في Ice." },
  { char: "J", lower: "j", name: "جاي", ipa: "/dʒ/", type: "consonant", word: "Juice", wordAr: "عصير", icon: "🧃", sentence: "I love drinking orange juice.", sentenceAr: "أحب شرب عصير البرتقال.", tips: "جيم معطشة دائماً مصحوبة بحرف الدال الخفيف." },
  { char: "K", lower: "k", name: "كاي", ipa: "/k/", type: "consonant", word: "King", wordAr: "ملك", icon: "👑", sentence: "The king lives in a castle.", sentenceAr: "الملك يعيش في قلعة.", tips: "حرف الكاف. يكون صامتاً إذا جاء بعده N مثل Know." },
  { char: "L", lower: "l", name: "إل", ipa: "/l/", type: "consonant", word: "Lion", wordAr: "أسد", icon: "🦁", sentence: "The lion is the king of the jungle.", sentenceAr: "الأسد هو ملك الغابة.", tips: "حرف اللام المرققة أو المفخمة." },
  { char: "M", lower: "m", name: "إم", ipa: "/m/", type: "consonant", word: "Moon", wordAr: "قمر", icon: "🌙", sentence: "The moon shines brightly tonight.", sentenceAr: "القمر يسطع بوضوح الليلة.", tips: "حرف الميم بإطباق الشفتين." },
  { char: "N", lower: "n", name: "إن", ipa: "/n/", type: "consonant", word: "Night", wordAr: "ليل", icon: "🌃", sentence: "Good night and sweet dreams.", sentenceAr: "تصبح على خير وأحلام سعيدة.", tips: "حرف النون بخروج الصوت من الأنف واللسان في سقف الحلق." },
  { char: "O", lower: "o", name: "أو", ipa: "/ɒ/ - /oʊ/", type: "vowel", word: "Orange", wordAr: "برتقال", icon: "🍊", sentence: "Oranges are rich in Vitamin C.", sentenceAr: "البرتقال غني بفيتامين سي.", tips: "حرف متحرك يمثل الضمة المفخمة." },
  { char: "P", lower: "p", name: "بي (مفخمة)", ipa: "/p/", type: "consonant", word: "Pen", wordAr: "قلم", icon: "🖊️", sentence: "Can I borrow your pen, please?", sentenceAr: "هل يمكنني استعارة قلمك من فضلك؟", tips: "انتبه: حرف P قوي يخرج معه هواء من الفم عكس B الهادئة!" },
  { char: "Q", lower: "q", name: "كيو", ipa: "/kw/", type: "consonant", word: "Queen", wordAr: "ملكة", icon: "👸", sentence: "The queen waved to the people.", sentenceAr: "لوحت الملكة للناس.", tips: "يأتي دائماً تقريباً متبوعاً بحرف U مثل Queen, Quick." },
  { char: "R", lower: "r", name: "آر", ipa: "/r/", type: "consonant", word: "River", wordAr: "نهر", icon: "🌊", sentence: "The river flows to the sea.", sentenceAr: "النهر يتدفق نحو البحر.", tips: "حرف الراء الإنجليزي بدون تكرار اللسان مع سقف الفم." },
  { char: "S", lower: "s", name: "إس", ipa: "/s/ or /z/", type: "consonant", word: "Sun", wordAr: "شمس", icon: "☀️", sentence: "The sun is shining today.", sentenceAr: "الشمس مشرقة اليوم.", tips: "حرف السين الصافي. أحياناً ينطق Z مثل Rose." },
  { char: "T", lower: "t", name: "تي", ipa: "/t/", type: "consonant", word: "Tree", wordAr: "شجرة", icon: "🌳", sentence: "Birds are singing in the tree.", sentenceAr: "الطيور تغرد على الشجرة.", tips: "حرف التاء الإنجليزي مع همس خفيف." },
  { char: "U", lower: "u", name: "يو", ipa: "/ʌ/ - /juː/", type: "vowel", word: "Umbrella", wordAr: "مظلة", icon: "☂️", sentence: "Take an umbrella, it might rain.", sentenceAr: "خذ مظلة، فقد تمطر.", tips: "حرف متحرك مثل الفتحة في Cup أو اليو في University." },
  { char: "V", lower: "v", name: "في", ipa: "/v/", type: "consonant", word: "Voice", wordAr: "صوت", icon: "🗣️", sentence: "She has a very pleasant voice.", sentenceAr: "لديها صوت لطيف للغاية.", tips: "حرف الـ V مع اهتزاز الأحبال الصوتية (مثل الفاء المعطشة)." },
  { char: "W", lower: "w", name: "دبليو", ipa: "/w/", type: "consonant", word: "Water", wordAr: "ماء", icon: "💧", sentence: "Drink plenty of water every day.", sentenceAr: "اشرب الكثير من الماء يومياً.", tips: "ينطق مثل حرف الواو العربي تماماً مثل Water." },
  { char: "X", lower: "x", name: "إكس", ipa: "/ks/", type: "consonant", word: "Box", wordAr: "صندوق", icon: "📦", sentence: "Open the surprise gift box.", sentenceAr: "افتح صندوق الهدية المفاجئة.", tips: "صوت مركب من الكاف والسين (ks)." },
  { char: "Y", lower: "y", name: "واي", ipa: "/j/ - /aɪ/", type: "consonant", word: "Yellow", wordAr: "أصفر", icon: "💛", sentence: "The yellow flower is beautiful.", sentenceAr: "الزهرة الصفراء جميلة.", tips: "ينطق كحرف الياء في Yellow أو آي في Fly." },
  { char: "Z", lower: "z", name: "زد / زي", ipa: "/z/", type: "consonant", word: "Zoo", wordAr: "حديقة حيوان", icon: "🦓", sentence: "Children love visiting the zoo.", sentenceAr: "الأطفال يحبون زيارة حديقة الحيوان.", tips: "حرف الزاي الصريح مع طنين خفيف." },
];

export default function AlphabetPage() {
  const [filter, setFilter] = useState<"all" | "vowel" | "consonant">("all");
  const [selectedLetter, setSelectedLetter] = useState<LetterData>(alphabetData[0]);

  // Mini Sound Quiz Game State
  const [quizIndex, setQuizIndex] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [quizQuestions] = useState(() => {
    // Generate 5 random questions
    const shuffled = [...alphabetData].sort(() => 0.5 - Math.random()).slice(0, 5);
    return shuffled;
  });

  const currentQuizLetter = quizQuestions[quizIndex];

  const handlePlayQuizSound = () => {
    if (currentQuizLetter) {
      playEnglishText(`Letter ${currentQuizLetter.char}, ${currentQuizLetter.word}`, 0.8);
    }
  };

  const handleQuizAnswer = (letterChar: string) => {
    if (letterChar === currentQuizLetter.char) {
      playSoundEffect("correct");
      setFeedback("correct");
      setQuizScore((prev) => prev + 1);
    } else {
      playSoundEffect("wrong");
      setFeedback("wrong");
    }

    setTimeout(() => {
      setFeedback(null);
      if (quizIndex < quizQuestions.length - 1) {
        setQuizIndex((prev) => prev + 1);
      }
    }, 1200);
  };

  const filteredLetters = alphabetData.filter((item) => {
    if (filter === "all") return true;
    return item.type === filter;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>المستوى التمهيدي (Pre-A1) • الوحدة 1</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white">
            دليل الحروف الإنجليزية والأصوات (The Alphabet & Phonics)
          </h1>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            تعلم نطق وكتابة الـ 26 حرفاً مع الحروف الكبيرة (Capital) والصغيرة (Small)، الحروف المتحركة (Vowels)، والأصوات المركبة مع تدريبات النطق الصوتي الفوري.
          </p>

          {/* Filter Pills */}
          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={() => setFilter("all")}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
                filter === "all"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              جميع الحروف (26)
            </button>
            <button
              onClick={() => setFilter("vowel")}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
                filter === "vowel"
                  ? "bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              حروف العلة المتحركة (A, E, I, O, U)
            </button>
            <button
              onClick={() => setFilter("consonant")}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
                filter === "consonant"
                  ? "bg-sky-500 text-slate-950 shadow-lg shadow-sky-500/30"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              الحروف الساكنة (21)
            </button>
          </div>
        </div>

        {/* Selected Letter Spotlight Card */}
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
            {/* Big Letter Representation */}
            <div className="flex flex-col items-center justify-center p-6 rounded-2xl bg-slate-950/80 border border-slate-800 text-center">
              <span className="text-6xl sm:text-8xl font-black bg-gradient-to-b from-white via-indigo-200 to-indigo-400 bg-clip-text text-transparent font-mono tracking-wider">
                {selectedLetter.char} {selectedLetter.lower}
              </span>
              <p className="text-xs text-indigo-300 font-semibold mt-2">
                اسم الحرف بالعربية: ({selectedLetter.name}) • الرمز الصوتي: {selectedLetter.ipa}
              </p>
              <div className="mt-4 flex items-center gap-2">
                <AudioButton
                  text={`Letter ${selectedLetter.char}. ${selectedLetter.word}.`}
                  size="md"
                  showSlowToggle={true}
                />
              </div>
            </div>

            {/* Word & Example */}
            <div className="space-y-4 lg:col-span-2">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {selectedLetter.type === "vowel" ? "حرف متحرك (Vowel)" : "حرف ساكن (Consonant)"}
                </span>
                <span className="text-2xl">{selectedLetter.icon}</span>
              </div>

              <div>
                <p className="text-xs text-slate-400">الكلمة النموذجية على هذا الحرف:</p>
                <div className="flex items-center gap-3 mt-1">
                  <h3 className="text-3xl font-extrabold text-white en-ltr">{selectedLetter.word}</h3>
                  <span className="text-lg font-bold text-indigo-300">({selectedLetter.wordAr})</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1">
                <p className="text-xs text-slate-400">مثال في جملة كاملة:</p>
                <p className="text-sm font-semibold text-white en-ltr">{selectedLetter.sentence}</p>
                <p className="text-xs text-slate-300">{selectedLetter.sentenceAr}</p>
              </div>

              <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200">
                <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <p><strong>تنبيه نطق:</strong> {selectedLetter.tips}</p>
              </div>
            </div>
          </div>
        </div>

        {/* 26 Letters Interactive Grid */}
        <div>
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-400" />
            <span>انقر على أي حرف للاستماع واستكشاف تفاصيله:</span>
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-7 xl:grid-cols-9 gap-3">
            {filteredLetters.map((item) => {
              const isSelected = selectedLetter.char === item.char;
              return (
                <button
                  key={item.char}
                  onClick={() => {
                    setSelectedLetter(item);
                    playEnglishText(`${item.char}, ${item.word}`, 0.9);
                  }}
                  className={`p-4 rounded-2xl flex flex-col items-center justify-center transition-all duration-150 cursor-pointer ${
                    isSelected
                      ? "bg-indigo-600 text-white ring-2 ring-indigo-400 shadow-xl shadow-indigo-600/30 scale-105"
                      : item.type === "vowel"
                      ? "bg-amber-950/20 hover:bg-amber-900/30 border border-amber-500/30 text-amber-200"
                      : "bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-200"
                  }`}
                >
                  <span className="text-2xl font-black font-mono">
                    {item.char} <span className="text-lg opacity-80">{item.lower}</span>
                  </span>
                  <span className="text-lg mt-1">{item.icon}</span>
                  <span className="text-[11px] font-medium mt-1 truncate max-w-full">{item.word}</span>
                  <span className="text-[10px] text-slate-400">({item.wordAr})</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Essential Digraphs & Phonics Rules */}
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-white">الأصوات المركبة الهامة (Digraphs)</h2>
            <p className="text-xs text-slate-400 mt-1">
              عند دمج حرفين معاً، يُنتج صوت جديد مختلف تماماً عن الحرفين منفردين:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xl font-bold text-indigo-400 font-mono">SH = ش</span>
                <AudioButton text="Ship. Shop. Fish. She is at the shop." size="sm" />
              </div>
              <p className="text-xs text-slate-300">يُنطق مثل حرف الشين العربي تماماً.</p>
              <div className="text-xs text-slate-400 space-y-0.5">
                <p>• <strong>Ship</strong> (سفينة) / <strong>Shop</strong> (محل) / <strong>Fish</strong> (سمكة)</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xl font-bold text-purple-400 font-mono">CH = تش</span>
                <AudioButton text="Chair. Cheese. Teacher. Sit on the chair." size="sm" />
              </div>
              <p className="text-xs text-slate-300">يُنطق (تش) بدمج التاء والشين معاً.</p>
              <div className="text-xs text-slate-400 space-y-0.5">
                <p>• <strong>Chair</strong> (كرسي) / <strong>Cheese</strong> (جبن) / <strong>Teacher</strong> (معلم)</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xl font-bold text-sky-400 font-mono">TH = ث أو ذ</span>
                <AudioButton text="Think. Thank you. This. That." size="sm" />
              </div>
              <p className="text-xs text-slate-300">يُنطق (ث) مثل Think، أو (ذ) مثل This و That.</p>
              <div className="text-xs text-slate-400 space-y-0.5">
                <p>• <strong>Think</strong> (يفكر - ث) / <strong>This</strong> (هذا - ذ) / <strong>Thank you</strong> (شكراً - ث)</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xl font-bold text-pink-400 font-mono">PH = ف</span>
                <AudioButton text="Phone. Photo. Elephant. Answer the phone." size="sm" />
              </div>
              <p className="text-xs text-slate-300">يُنطق دائماً كحرف الفاء (F).</p>
              <div className="text-xs text-slate-400 space-y-0.5">
                <p>• <strong>Phone</strong> (هاتف) / <strong>Photo</strong> (صورة) / <strong>Elephant</strong> (فيل)</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xl font-bold text-amber-400 font-mono">WH = و</span>
                <AudioButton text="What. Where. When. Why. What is your name?" size="sm" />
              </div>
              <p className="text-xs text-slate-300">يُنطق كحرف الواو وتكون الـ H صامتة في أدوات الاستفهام.</p>
              <div className="text-xs text-slate-400 space-y-0.5">
                <p>• <strong>What</strong> (ماذا) / <strong>Where</strong> (أين) / <strong>When</strong> (متى)</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xl font-bold text-emerald-400 font-mono">Silent Letters</span>
                <AudioButton text="Know. Knee. Write. Wrong. Comb. Doubt." size="sm" />
              </div>
              <p className="text-xs text-slate-300">حروف تكتب ولا تنطق في مواضع محددة.</p>
              <div className="text-xs text-slate-400 space-y-0.5">
                <p>• <strong>K</strong> قبل N: Know (يعرف) / <strong>W</strong> قبل R: Write (يكتب)</p>
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Alphabet Sound Quiz Mini-Game */}
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-indigo-950/80 via-slate-900 to-purple-950/80 border border-indigo-500/30 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-indigo-600/30 text-indigo-300">
                  <Gamepad2 className="w-5 h-5" />
                </span>
                <h2 className="text-xl font-bold text-white">تحدي الاستماع للحروف (Phonics Mini Quiz)</h2>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                استمع للصوت المنطوق ثم اختر الحرف الصحيح المطابق له:
              </p>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                السؤال {quizIndex + 1} من {quizQuestions.length}
              </span>
              <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                النقاط: {quizScore} 🌟
              </span>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-950/80 border border-slate-800 text-center space-y-4">
            <p className="text-sm text-slate-300">انقر للاستماع إلى الحرف:</p>
            <button
              onClick={handlePlayQuizSound}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 inline-flex items-center gap-2 transition transform hover:scale-105"
            >
              <Volume2 className="w-5 h-5 animate-pulse" />
              <span>تشغيل صوت الحرف 🔊</span>
            </button>

            {/* Answer Options */}
            <div className="pt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-lg mx-auto">
              {[
                currentQuizLetter.char,
                alphabetData[(alphabetData.indexOf(currentQuizLetter) + 3) % 26].char,
                alphabetData[(alphabetData.indexOf(currentQuizLetter) + 7) % 26].char,
                alphabetData[(alphabetData.indexOf(currentQuizLetter) + 12) % 26].char,
              ]
                .sort()
                .map((charOption) => (
                  <button
                    key={charOption}
                    onClick={() => handleQuizAnswer(charOption)}
                    className="py-4 rounded-xl bg-slate-900 hover:bg-indigo-600 text-white text-xl font-bold font-mono border border-slate-800 hover:border-indigo-400 transition transform active:scale-95"
                  >
                    {charOption}
                  </button>
                ))}
            </div>

            {feedback && (
              <div
                className={`p-3 rounded-xl text-xs font-bold animate-in fade-in duration-200 ${
                  feedback === "correct"
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                    : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                }`}
              >
                {feedback === "correct"
                  ? `🎉 إجابة صحيحة! الحرف هو ${currentQuizLetter.char} (${currentQuizLetter.word})`
                  : `❌ إجابة خاطئة! الحرف الصحيح هو ${currentQuizLetter.char}`}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
