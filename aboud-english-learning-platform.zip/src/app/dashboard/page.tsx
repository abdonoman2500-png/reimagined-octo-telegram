"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { LevelBadge } from "@/components/LevelBadge";
import {
  Sparkles,
  Flame,
  Award,
  BookOpen,
  CheckCircle2,
  Bookmark,
  Compass,
  MessageSquare,
  Volume2,
  Gamepad2,
  ArrowLeft,
  Loader2,
  Zap,
} from "lucide-react";

export default function DashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadProgress() {
      try {
        const res = await fetch("/api/progress");
        const data = await res.json();
        setStats(data);
      } catch (err) {
        console.error("Load progress error", err);
      } finally {
        setLoading(false);
      }
    }
    loadProgress();
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Welcome Header */}
        <div className="p-8 rounded-3xl bg-gradient-to-r from-blue-950/60 via-indigo-950/60 to-purple-950/60 border border-indigo-500/30 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-indigo-300 bg-indigo-500/20 px-3 py-1 rounded-full border border-indigo-500/30">
                لوحة الطالب التفاعلية
              </span>
              <LevelBadge level={user?.currentLevel || "Pre-A1"} />
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
              أهلاً بك، {user?.name || "طالب العلم"}! 👋
            </h1>
            <p className="text-xs sm:text-sm text-slate-300">
              تابع دروسك اليومية، راجع الكلمات المفضلة، واجمع نقاط الخبرة للوصول إلى المستوى التالي.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {/* Streak */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-center">
              <div className="flex items-center justify-center gap-1.5 text-amber-400">
                <Flame className="w-5 h-5 fill-current" />
                <span className="text-xl font-bold">{user?.streakDays || 1}</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">أيام الالتزام</p>
            </div>

            {/* XP */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-center">
              <div className="flex items-center justify-center gap-1.5 text-indigo-300">
                <Zap className="w-5 h-5 text-indigo-400" />
                <span className="text-xl font-bold">{user?.xp || 100}</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">نقاط XP</p>
            </div>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{stats?.completedLessonsCount || 0}</p>
              <p className="text-xs text-slate-400">دروس مكتملة</p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-amber-600/20 text-amber-400 flex items-center justify-center shrink-0">
              <Bookmark className="w-6 h-6" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{stats?.savedWordsCount || 0}</p>
              <p className="text-xs text-slate-400">كلمات محفوظة</p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center shrink-0">
              <Gamepad2 className="w-6 h-6" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{stats?.quizzesTaken || 0}</p>
              <p className="text-xs text-slate-400">اختبارات منجزة</p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{stats?.certificates?.length || 0}</p>
              <p className="text-xs text-slate-400">شهادات إتمام</p>
            </div>
          </div>
        </div>

        {/* Continue Learning CTA & Shortcuts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Quick Continue Card */}
          <div className="lg:col-span-2 p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-indigo-400">متابعة المسار التعليمي</span>
                <span className="text-xs text-slate-400">{stats?.progressPercentage || 0}% مكتمل</span>
              </div>

              <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(stats?.progressPercentage || 10, 10)}%` }}
                ></div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-white">
                  المستوى الحالي: {user?.currentLevel || "Pre-A1"}
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  استمر في دراسة القواعد والكلمات والمحادثات للحصول على شهادة إتمام هذا المستوى.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-6">
              <Link
                href={user?.currentLevel === "Pre-A1" ? "/alphabet" : "/grammar"}
                className="px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/25 flex items-center gap-2 transition"
              >
                <span>متابعة آخر درس الآن</span>
                <ArrowLeft className="w-4 h-4" />
              </Link>

              <Link
                href="/placement-test"
                className="px-5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition"
              >
                إعادة اختبار تحديد المستوى
              </Link>
            </div>
          </div>

          {/* Quick Shortcuts */}
          <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3">
            <h3 className="font-bold text-sm text-white mb-2">أقسام التعلم السريع:</h3>

            <Link
              href="/alphabet"
              className="flex items-center justify-between p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-200 text-xs font-medium transition"
            >
              <div className="flex items-center gap-2.5">
                <BookOpen className="w-4 h-4 text-sky-400" />
                <span>الحروف والأصوات (Pre-A1)</span>
              </div>
              <span>←</span>
            </Link>

            <Link
              href="/vocabulary"
              className="flex items-center justify-between p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-200 text-xs font-medium transition"
            >
              <div className="flex items-center gap-2.5">
                <Bookmark className="w-4 h-4 text-amber-400" />
                <span>القاموس والمفردات</span>
              </div>
              <span>←</span>
            </Link>

            <Link
              href="/grammar"
              className="flex items-center justify-between p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-200 text-xs font-medium transition"
            >
              <div className="flex items-center gap-2.5">
                <Compass className="w-4 h-4 text-blue-400" />
                <span>دروس القواعد والأزمنة</span>
              </div>
              <span>←</span>
            </Link>

            <Link
              href="/conversations"
              className="flex items-center justify-between p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-200 text-xs font-medium transition"
            >
              <div className="flex items-center gap-2.5">
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>المحادثات اليومية</span>
              </div>
              <span>←</span>
            </Link>

            <Link
              href="/certificates"
              className="flex items-center justify-between p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-200 text-xs font-medium transition"
            >
              <div className="flex items-center gap-2.5">
                <Award className="w-4 h-4 text-purple-400" />
                <span>الشهادات المكتسبة</span>
              </div>
              <span>←</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
