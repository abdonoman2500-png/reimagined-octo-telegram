"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { AudioButton } from "@/components/AudioButton";
import { LevelBadge } from "@/components/LevelBadge";
import {
  GraduationCap,
  Sparkles,
  ArrowLeft,
  BookOpen,
  Volume2,
  Award,
  CheckCircle,
  Flame,
  MessageSquare,
  Compass,
  Bookmark,
  Gamepad2,
  Users,
  ShieldCheck,
  Star,
  Play,
  Zap,
} from "lucide-react";

export default function HomePage() {
  const { user, quickLogin } = useAuth();
  const [levels, setLevels] = useState<any[]>([]);
  const [loadingLevels, setLoadingLevels] = useState(true);

  useEffect(() => {
    async function loadLevels() {
      try {
        const res = await fetch("/api/levels");
        const data = await res.json();
        if (data.levels) {
          setLevels(data.levels);
        }
      } catch (err) {
        console.error("Failed to load levels", err);
      } finally {
        setLoadingLevels(false);
      }
    }
    loadLevels();
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-12 pb-20 md:pt-20 md:pb-32 px-4 sm:px-6 lg:px-8 glow-gradient">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900/20 via-slate-950/80 to-slate-950 pointer-events-none"></div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center max-w-3xl mx-auto space-y-6">
            {/* Pill Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs sm:text-sm font-medium backdrop-blur-md animate-fade-in">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>منصة تعلّم الإنجليزية الأولى باللغة العربية من الصفر حتى الاحتراف</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white leading-tight">
              تعلّم الإنجليزية بثقة مع{" "}
              <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">
                «منصة عَبّود»
              </span>
            </h1>

            {/* Subheading */}
            <p className="text-base sm:text-lg md:text-xl text-slate-300 leading-relaxed max-w-2xl mx-auto">
              ابدأ من الحروف والأصوات حتى الطلاقة التامة. شروحات عربية واضحة، نطق صوتي أصلي، محادثات يومية واقعية، واختبارات تفاعلية تضمن إتقانك لكل مستوى.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Link
                href="/alphabet"
                className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-semibold text-base shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 group transition duration-200 transform hover:-translate-y-0.5"
              >
                <span>ابدأ من الحروف (Pre-A1)</span>
                <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              </Link>

              <Link
                href="/placement-test"
                className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 font-semibold text-base border border-slate-700/80 hover:border-indigo-500/50 flex items-center justify-center gap-2 transition duration-200 shadow-lg"
              >
                <Award className="w-5 h-5 text-indigo-400" />
                <span>اختبار تحديد مستواك المجاني</span>
              </Link>
            </div>

            {/* Social Proof / Stats Counter */}
            <div className="pt-8 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm text-center">
                <p className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-blue-400 to-indigo-300 bg-clip-text text-transparent">
                  7 مستويات
                </p>
                <p className="text-xs text-slate-400 mt-1">من Pre-A1 حتى C2</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm text-center">
                <p className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-indigo-400 to-purple-300 bg-clip-text text-transparent">
                  +100 درس
                </p>
                <p className="text-xs text-slate-400 mt-1">شروحات عربية وتمارين</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm text-center">
                <p className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-300 bg-clip-text text-transparent">
                  100% صوتي
                </p>
                <p className="text-xs text-slate-400 mt-1">نطق إنجليزي فوري وبطيء</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm text-center">
                <p className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent">
                  شهادات إتمام
                </p>
                <p className="text-xs text-slate-400 mt-1">توثيق رقمي لكل مستوى</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Word of the Day + Quick Daily Practice Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-20 mb-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Word of the Day Card */}
          <div className="lg:col-span-2 p-6 rounded-3xl bg-gradient-to-br from-slate-900/90 via-indigo-950/40 to-slate-900/90 border border-indigo-500/20 shadow-2xl backdrop-blur-xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

            <div className="flex items-center justify-between mb-4">
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-300 bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full">
                <Sparkles className="w-3.5 h-3.5" />
                كلمة اليوم (Word of the Day)
              </span>
              <LevelBadge level="B1" size="sm" />
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-3">
                  <h3 className="text-2xl sm:text-3xl font-bold text-white en-ltr">Opportunity</h3>
                  <span className="text-xs text-slate-400">/ˌɒp.əˈtʃuː.nə.ti/ • اسم (Noun)</span>
                </div>
                <p className="text-lg font-medium text-indigo-300 mt-1">المعنى بالعربية: فرصة سانحة / مناسبة مواتية</p>
                <p className="text-sm text-slate-300 mt-2 bg-slate-800/50 p-2.5 rounded-xl border border-slate-700/50">
                  <span className="font-semibold text-white en-ltr">"This platform is a great opportunity to learn English."</span>
                  <br />
                  <span className="text-xs text-slate-400">«هذه المنصة فرصة عظيمة لتعلّم اللغة الإنجليزية.»</span>
                </p>
              </div>

              <div className="flex flex-col sm:items-end gap-2 shrink-0">
                <AudioButton text="Opportunity. This platform is a great opportunity to learn English." size="md" showSlowToggle={true} />
                <Link
                  href="/vocabulary"
                  className="text-xs text-indigo-400 hover:text-indigo-300 underline font-medium"
                >
                  استكشف القاموس الكامل ←
                </Link>
              </div>
            </div>
          </div>

          {/* Quick Level Placement CTA */}
          <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-4">
                <Award className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white">لا تعرف من أين تبدأ؟</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                قم بإجراء اختبار تحديد المستوى السريع (12 سؤالاً فقط) لنحدد لك بدقة المستوى المناسب وخطتك التعليمية.
              </p>
            </div>
            <Link
              href="/placement-test"
              className="mt-4 w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold text-center transition shadow-lg shadow-indigo-600/20"
            >
              بدء الاختبار الآن (3 دقائق)
            </Link>
          </div>
        </div>
      </section>

      {/* CEFR Learning Roadmap (Pre-A1 to C2) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-semibold text-indigo-400 tracking-wider uppercase">المسارات التعليمية المعتمدة</span>
          <h2 className="text-3xl font-bold text-white mt-1">تدرّج تدريجي مدروس خطوة بخطوة</h2>
          <p className="text-sm text-slate-400 mt-2">
            من الحروف الأولى والأصوات الأساسية، إلى التحدث بطلاقة وإتقان القواعد الأكاديمية.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {/* Level Pre-A1 */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-sky-500/20 hover:border-sky-500/40 transition duration-200 group flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <LevelBadge level="Pre-A1" />
                <span className="text-xs text-sky-400 font-medium">المبتدئ تماماً</span>
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-sky-300 transition">الحروف والأصوات من الصفر</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                الحروف الـ 26، الأصوات المركبة، النطق الصوتي الصحيح، الأرقام والتحيات الأولى.
              </p>
            </div>
            <Link
              href="/alphabet"
              className="mt-6 flex items-center justify-between text-xs font-semibold text-sky-400 group-hover:text-sky-300 pt-3 border-t border-slate-800"
            >
              <span>ابدأ درس الحروف</span>
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* Level A1 */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-blue-500/20 hover:border-blue-500/40 transition duration-200 group flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <LevelBadge level="A1" />
                <span className="text-xs text-blue-400 font-medium">المستوى المبتدئ</span>
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-blue-300 transition">تكوين الجمل والمضارع البسيط</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                الضمائر، فعل الكينونة (am/is/are)، الروتين اليومي، ومحادثات التعارف والمطعم.
              </p>
            </div>
            <Link
              href="/grammar"
              className="mt-6 flex items-center justify-between text-xs font-semibold text-blue-400 group-hover:text-blue-300 pt-3 border-t border-slate-800"
            >
              <span>استكشف قواعد A1</span>
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* Level A2 */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-indigo-500/20 hover:border-indigo-500/40 transition duration-200 group flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <LevelBadge level="A2" />
                <span className="text-xs text-indigo-400 font-medium">فوق المبتدئ</span>
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-indigo-300 transition">الماضي والمستقبل والسفر</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                الماضي البسيط للأفعال، خطط المستقبل بـ will و going to، ومحادثات المطار والفندق.
              </p>
            </div>
            <Link
              href="/conversations"
              className="mt-6 flex items-center justify-between text-xs font-semibold text-indigo-400 group-hover:text-indigo-300 pt-3 border-t border-slate-800"
            >
              <span>محادثات مستوى A2</span>
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* Level B1 */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-violet-500/20 hover:border-violet-500/40 transition duration-200 group flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <LevelBadge level="B1" />
                <span className="text-xs text-violet-400 font-medium">المستوى المتوسط</span>
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-violet-300 transition">المضارع التام والأفعال الناقصة</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                Present Perfect (have/has + V3)، أفعال الإلزام can/must/should، والنصوص المتوسطة.
              </p>
            </div>
            <Link
              href="/grammar"
              className="mt-6 flex items-center justify-between text-xs font-semibold text-violet-400 group-hover:text-violet-300 pt-3 border-t border-slate-800"
            >
              <span>دروس مستوى B1</span>
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* Level B2 */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-purple-500/20 hover:border-purple-500/40 transition duration-200 group flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <LevelBadge level="B2" />
                <span className="text-xs text-purple-400 font-medium">فوق المتوسط</span>
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-purple-300 transition">الجمل الشرطية والمبني للمجهول</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                قواعد If الشرطية الأربعة، Passive Voice، ومقابلات العمل والمفاوضات المهنية.
              </p>
            </div>
            <Link
              href="/conversations"
              className="mt-6 flex items-center justify-between text-xs font-semibold text-purple-400 group-hover:text-purple-300 pt-3 border-t border-slate-800"
            >
              <span>محادثات المقابلات B2</span>
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* Level C1 */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-fuchsia-500/20 hover:border-fuchsia-500/40 transition duration-200 group flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <LevelBadge level="C1" />
                <span className="text-xs text-fuchsia-400 font-medium">المستوى المتقدم</span>
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-fuchsia-300 transition">التعبيرات الاصطلاحية (Idioms)</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                أمثال إنجليزية شائعة، العبارات الاصطلاحية للمتحدثين الأصليين، والقواعد الأكاديمية.
              </p>
            </div>
            <Link
              href="/vocabulary"
              className="mt-6 flex items-center justify-between text-xs font-semibold text-fuchsia-400 group-hover:text-fuchsia-300 pt-3 border-t border-slate-800"
            >
              <span>قاموس تعبيرات C1</span>
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* Level C2 */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-rose-500/20 hover:border-rose-500/40 transition duration-200 group flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <LevelBadge level="C2" />
                <span className="text-xs text-rose-400 font-medium">الطلاقة والاحتراف</span>
              </div>
              <h3 className="text-lg font-bold text-white group-hover:text-rose-300 transition">البلاغة والكتابة الاحترافية</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                الفروق الدقيقة المتقدمة بين المترادفات، الأسلوب الإقناعي، وفهم اللهجات المعقدة.
              </p>
            </div>
            <Link
              href="/reading-writing"
              className="mt-6 flex items-center justify-between text-xs font-semibold text-rose-400 group-hover:text-rose-300 pt-3 border-t border-slate-800"
            >
              <span>القراءة والكتابة C2</span>
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* Comprehensive Placement Exam Box */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-900/60 to-purple-900/60 border border-indigo-400/40 flex flex-col justify-between shadow-xl">
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/30">
                  شهادة المنصة 🎓
                </span>
              </div>
              <h3 className="text-lg font-bold text-white">اختبر مستواك الآن واحصل على شهادتك</h3>
              <p className="text-xs text-indigo-200 mt-2 leading-relaxed">
                اجتز اختبارات المستويات واحصل على شهادة إتمام رسمية برقم تحقق لملفك التعليمي.
              </p>
            </div>
            <Link
              href="/placement-test"
              className="mt-6 w-full py-2.5 rounded-xl bg-white text-indigo-950 font-bold text-xs text-center hover:bg-slate-100 transition shadow"
            >
              بدء الاختبار والتقييم
            </Link>
          </div>
        </div>
      </section>

      {/* Core Platform Features Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 bg-slate-900/40 rounded-3xl border border-slate-800/80 mb-20">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl font-bold text-white">لماذا منصة عبود هي خيارك الأمثل؟</h2>
          <p className="text-sm text-slate-400 mt-2">
            تم بناء المنصة خصيصاً للمتعلم العربي مع تلافي العوائق التقليدية التي تواجه المبتدئين.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex gap-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">شرح عربي مبسط ومنطقي</h3>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                لا نكتفي بذكر القاعدة بل نشرح سبب استخدامها وربطها باللغة العربية مع توضيح الفروق الدقيقة.
              </p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex gap-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/20 text-purple-400 flex items-center justify-center shrink-0 border border-purple-500/30">
              <Volume2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">نطق صوتي مع تحكم بالسرعة</h3>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                استمع لكل حرف وكلمة وجملة بنطق إنجليزي سليم مع خيار الاستماع البطيء لتدريب الأذن للمبتدئين.
              </p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">محادثات واقعية حية</h3>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                حوارات بالمطار والمطاعم والمقابلات والعيادات مع خاصية إظهار وإخفاء الترجمة وتكرار الصوت.
              </p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-600/20 text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/30">
              <Bookmark className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">قاموس وبطاقات مراجعة ذكية</h3>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                احفظ أي كلمة في قائمتك المفضلة وراجعها بنظام التكرار المتباعد والبطاقات التعليمية (Flashcards).
              </p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex gap-4">
            <div className="w-12 h-12 rounded-2xl bg-pink-600/20 text-pink-400 flex items-center justify-center shrink-0 border border-pink-500/30">
              <Gamepad2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">ألعاب واختبارات تفاعلية</h3>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                أنماط متعددة من الأسئلة: مطابقة الكلمات، ترتيب الجمل، الاستماع، مع تفسير فوري للإجابات الخاطئة.
              </p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex gap-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center shrink-0 border border-indigo-500/30">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">شهادات إتمام وسجل إنجازات</h3>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                احصل على شهادة إتمام رقمية برقم تسلسلي موثق وسجل متكامل بنقاطك وعدد أيام التزامك (Streak).
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call To Action Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-blue-900/80 via-indigo-900/80 to-purple-900/80 border border-indigo-500/30 text-center space-y-6 relative overflow-hidden shadow-2xl">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/10 to-transparent pointer-events-none"></div>

          <span className="inline-block px-3 py-1 rounded-full bg-white/10 text-indigo-200 text-xs font-semibold backdrop-blur-md">
            جاهز للانطلاق في رحلة تعلّم ممتعة؟
          </span>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            ابدأ تعلّم الإنجليزية الآن مع منصة عبود مجاناً
          </h2>

          <p className="text-sm sm:text-base text-slate-200 max-w-xl mx-auto leading-relaxed">
            انضم إلى آلاف الطلاب الذين غيروا مستواهم في اللغة الإنجليزية من خلال دروسنا التفاعلية المبسطة.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <Link
              href="/auth/register"
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-white text-indigo-950 font-bold text-sm shadow-xl hover:bg-slate-100 transition duration-150 transform hover:-translate-y-0.5"
            >
              أنشئ حسابك المجاني في 10 ثوانٍ
            </Link>
            <Link
              href="/alphabet"
              className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-indigo-950/60 hover:bg-indigo-950 text-indigo-200 font-semibold text-sm border border-indigo-400/40 transition"
            >
              تصفح الدروس كزائر
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
