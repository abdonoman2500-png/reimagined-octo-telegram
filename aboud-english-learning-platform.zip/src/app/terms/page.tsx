import React from "react";
import { FileText, Award, CheckCircle2 } from "lucide-react";

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
            <FileText className="w-3.5 h-3.5" />
            <span>الشروط والأحكام الأكاديمية</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white">شروط الاستخدام</h1>
          <p className="text-xs sm:text-sm text-slate-400">آخر تحديث: 2025</p>
        </div>

        <div className="p-8 sm:p-10 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed shadow-xl">
          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white">1. قبول الشروط</h2>
            <p>
              باستخدامك لمنصة عبود لتعلّم اللغة الإنجليزية، فإنك توافق على الالتزام بشروط الاستخدام الموضحة في هذه الصفحة واستخدام المحتوى للأغراض التعليمية الشخصية.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-400" />
              <span>2. طبيعة الشهادات الصادرة</span>
            </h2>
            <p className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 text-slate-200">
              * توضيح رسمي: الشهادات الصادرة من الموقع هي شهادات إتمام رقمية صادرة من منصة عبود التعليمية لتوثيق اجتياز الطالب للمقررات والاختبارات التفاعلية الخاصة بالمنصة بنجاح، ولا يُدعى أنها شهادات معتمدة حكومياً أو أكاديمياً من جهات خارجية ما لم يتم النص صراحة على شراكة رسمية معتمدة.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white">3. حقوق الملكية الفكرية</h2>
            <p>
              جميع النصوص التعليمية، وقواعد الشرح المكتوبة بالعربية، والتصميمات والشعارات مملوكة لمنصة عبود ومحمية بموجب قوانين الملكية الفكرية. يُمنع نسخ المحتوى أو إعادة نشره تجارياً دون إذن مسبق.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white">4. السلوك والاستخدام المقبول</h2>
            <p>
              يُحظر استخدام المنصة بأي طريقة قد تضر بالبنية التحتية للخوادم أو تعطيل وصول الطلاب الآخرين إلى الخدمات التعليمية.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
