"use client";

import React, { useState } from "react";
import Link from "next/link";
import { HelpCircle, ChevronDown, ChevronUp, Sparkles, BookOpen } from "lucide-react";

const faqs = [
  {
    q: "هل المنصة مناسبة لمن يبدأ من الصفر تماماً؟",
    a: "نعم تماماً! تبدأ المنصة من مستوى Pre-A1 لشرح الحروف الإنجليزية الـ 26، أصواتها، قواعد النطق ومخارج الحروف، باللغة العربية البسيطة والأمثلة الصوتية الواضحة.",
  },
  {
    q: "كيف يعمل نظام تحديد المستوى واختباراته؟",
    a: "يتكون اختبار تحديد المستوى من 12 سؤالاً متدرجة الصعوبة تغطي معايير الإطار الأوروبي CEFR (من Pre-A1 إلى C1). بعد إنهاء الاختبار، يحدد النظام مستواك بدقة ويوجهك للوحدات المناسبة فوراً.",
  },
  {
    q: "هل النطق الصوتي متوفر لجميع الكلمات والجمل؟",
    a: "نعم، جميع الحروف والمفردات وقواعد اللغة ونصوص المحادثات مدعومة بمشغل صوتي فوري بنطق متحدثين أصليين، مع خيار تشغيل الصوت البطيء (0.55x) لتدريب الأذن للمبتدئين.",
  },
  {
    q: "كيف أحصل على شهادة إتمام المستوى؟",
    a: "عند إكمال دروس المستوى واجتياز الاختبار الشامل بنسبة لا تقل عن 70%، يتم إصدار شهادة إتمام رسمية برقم تسلسلي فريد يمكن التحقق منه ومشاركتها في ملفك الشخصي.",
  },
  {
    q: "هل أحتاج لدفع أي رسوم؟",
    a: "جميع الدروس والاختبارات وقاموس المفردات والمحادثات متاحة مجاناً لجميع الطلاب المسجلين.",
  },
  {
    q: "كيف أقوم بتدريب مهارة التحدث والنطق بالميكروفون؟",
    a: "في صفحة المحادثات، يمكنك النقر على زر الميكروفون بعد السماح للمتصفح بالوصول إليه، ونطق الجملة ليقوم النظام بالتقاط صوتك ومقارنته بنطق الجملة النموذجي.",
  },
];

export default function FaqPage() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-10">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>مركز المساعدة والأسئلة الشائعة</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white">الأسئلة الشائعة (FAQ)</h1>
          <p className="text-xs sm:text-sm text-slate-400">
            إجابات شاملة عن كيفية استخدام المنصة، مستويات CEFR، النطق الصوتي، والشهادات.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 transition shadow-lg"
              >
                <button
                  onClick={() => toggle(idx)}
                  className="w-full flex items-center justify-between text-right gap-4 cursor-pointer"
                >
                  <h3 className="font-bold text-sm sm:text-base text-white">{faq.q}</h3>
                  <span className="p-1 rounded-lg bg-slate-800 text-slate-300 shrink-0">
                    {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </span>
                </button>

                {isOpen && (
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mt-4 pt-4 border-t border-slate-800 animate-in fade-in">
                    {faq.a}
                  </p>
                )}
              </div>
            );
          })}
        </div>

        <div className="p-8 rounded-3xl bg-slate-900/60 border border-slate-800 text-center space-y-3">
          <h4 className="font-bold text-white text-base">هل لديك سؤال آخر لم تجد إجابته هنا؟</h4>
          <p className="text-xs text-slate-400">فريق الدعم الفني جاهز لمساعدتك في أي وقت.</p>
          <Link
            href="/contact"
            className="inline-block mt-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition"
          >
            تواصل مع فريق الدعم ←
          </Link>
        </div>
      </div>
    </div>
  );
}
