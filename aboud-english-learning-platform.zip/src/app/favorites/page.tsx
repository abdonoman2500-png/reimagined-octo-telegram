"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { AudioButton } from "@/components/AudioButton";
import { LevelBadge } from "@/components/LevelBadge";
import { playSoundEffect } from "@/lib/speech";
import {
  Bookmark,
  Sparkles,
  Layers,
  RotateCw,
  CheckCircle2,
  Clock,
  Trash2,
  BookOpen,
  Loader2,
  Volume2,
} from "lucide-react";

interface FavoriteItem {
  id: number;
  vocabId: number;
  mastered: boolean;
  word: string;
  phonetic: string;
  partOfSpeech: string;
  translationAr: string;
  levelCode: string;
  category: string;
  exampleEn: string;
  exampleAr: string;
}

export default function FavoritesPage() {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<"list" | "flashcard">("list");

  // Flashcard mode state
  const [cardIndex, setCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  useEffect(() => {
    async function loadFavorites() {
      try {
        const res = await fetch("/api/vocabulary/favorite");
        const data = await res.json();
        if (data.favorites) {
          setFavorites(data.favorites);
        }
      } catch (err) {
        console.error("Load favorites failed", err);
      } finally {
        setLoading(false);
      }
    }
    loadFavorites();
  }, []);

  const handleToggleMastery = async (vocabId: number, currentMastered: boolean) => {
    const nextMastered = !currentMastered;
    try {
      await fetch("/api/vocabulary/favorite", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ vocabId, mastered: nextMastered }),
      });

      setFavorites((prev) =>
        prev.map((f) => (f.vocabId === vocabId ? { ...f, mastered: nextMastered } : f))
      );

      if (nextMastered) playSoundEffect("correct");
    } catch (err) {
      console.error("Toggle mastery failed", err);
    }
  };

  const handleRemoveFavorite = async (vocabId: number) => {
    try {
      await fetch("/api/vocabulary/favorite", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ vocabId }),
      });

      setFavorites((prev) => prev.filter((f) => f.vocabId !== vocabId));
    } catch (err) {
      console.error("Remove favorite failed", err);
    }
  };

  const currentFlashcard = favorites[cardIndex];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-2">
              <Bookmark className="w-3.5 h-3.5" />
              <span>مفرداتي المفضلة وبطاقات المراجعة</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
              الكلمات المحفوظة والمراجعة الذكية
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              راجع الكلمات التي قمت بحفظها أثناء الدراسة بنظام البطاقات التعليمية التفاعلية (Flashcards).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setViewMode("list");
                setIsFlipped(false);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                viewMode === "list"
                  ? "bg-indigo-600 text-white"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              عرض القائمة ({favorites.length})
            </button>
            <button
              onClick={() => {
                setViewMode("flashcard");
                setIsFlipped(false);
              }}
              disabled={favorites.length === 0}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition disabled:opacity-40 ${
                viewMode === "flashcard"
                  ? "bg-amber-500 text-slate-950 font-bold"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              وضع البطاقات (Flashcards) 🎴
            </button>
          </div>
        </div>

        {loading ? (
          <div className="py-20 text-center space-y-3">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-400 mx-auto" />
            <p className="text-xs text-slate-400">جارٍ جلب الكلمات المحفوظة...</p>
          </div>
        ) : favorites.length === 0 ? (
          <div className="p-12 rounded-3xl bg-slate-900/60 border border-slate-800 text-center space-y-4">
            <Bookmark className="w-12 h-12 text-slate-600 mx-auto" />
            <h3 className="text-xl font-bold text-white">لم تقم بحفظ أي كلمات بعد</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              تصفح القاموس وأضف الكلمات الجديدة إلى المفضلة لتظهر هنا وتراجعها بانتظام.
            </p>
            <Link
              href="/vocabulary"
              className="inline-block mt-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg transition"
            >
              تصفح قاموس الكلمات الآن
            </Link>
          </div>
        ) : viewMode === "list" ? (
          /* List Mode */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favorites.map((item) => (
              <div
                key={item.id}
                className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-indigo-500/40 transition flex flex-col justify-between shadow-xl"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <LevelBadge level={item.levelCode} size="sm" />
                    <button
                      onClick={() => handleRemoveFavorite(item.vocabId)}
                      title="إزالة من المفضلة"
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-2xl font-bold text-white en-ltr">{item.word}</h3>
                      {item.phonetic && (
                        <p className="text-xs text-indigo-400 font-mono en-ltr">{item.phonetic}</p>
                      )}
                    </div>
                    <AudioButton text={item.word} size="sm" showSlowToggle={true} />
                  </div>

                  <p className="text-sm font-semibold text-slate-200 mt-2">{item.translationAr}</p>

                  {item.exampleEn && (
                    <div className="mt-3 p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 text-xs space-y-0.5">
                      <p className="text-slate-200 en-ltr">{item.exampleEn}</p>
                      <p className="text-slate-400">{item.exampleAr}</p>
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                  <button
                    onClick={() => handleToggleMastery(item.vocabId, item.mastered)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
                      item.mastered
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                        : "bg-slate-800 text-slate-400 hover:text-white border border-slate-700"
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{item.mastered ? "تم الإتقان ✓" : "قيد التعلّم"}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* 3D Flashcards Review Mode */
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>
                بطاقة {cardIndex + 1} من {favorites.length}
              </span>
              <span>انقر على البطاقة لقلبها ومعرفة الترجمة</span>
            </div>

            {/* Flashcard Box */}
            <div
              onClick={() => setIsFlipped(!isFlipped)}
              className="p-10 rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 border-2 border-indigo-500/40 shadow-2xl min-h-[320px] flex flex-col justify-between text-center cursor-pointer transition transform hover:scale-[1.01]"
            >
              <div className="flex items-center justify-between">
                <LevelBadge level={currentFlashcard.levelCode} size="sm" />
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>اقلب البطاقة</span>
                </span>
              </div>

              {!isFlipped ? (
                /* Front: English Word */
                <div className="space-y-4 py-6">
                  <h2 className="text-4xl sm:text-5xl font-black text-white en-ltr">
                    {currentFlashcard.word}
                  </h2>
                  {currentFlashcard.phonetic && (
                    <p className="text-sm text-indigo-300 font-mono en-ltr">
                      {currentFlashcard.phonetic}
                    </p>
                  )}
                  <div className="pt-2">
                    <AudioButton text={currentFlashcard.word} size="md" showSlowToggle={true} />
                  </div>
                </div>
              ) : (
                /* Back: Arabic Meaning & Example */
                <div className="space-y-4 py-4 animate-in fade-in">
                  <h2 className="text-3xl font-extrabold text-amber-300">
                    {currentFlashcard.translationAr}
                  </h2>

                  {currentFlashcard.exampleEn && (
                    <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs space-y-1">
                      <p className="text-white font-bold en-ltr">{currentFlashcard.exampleEn}</p>
                      <p className="text-slate-400">{currentFlashcard.exampleAr}</p>
                    </div>
                  )}
                </div>
              )}

              <div className="text-[11px] text-slate-500">
                {isFlipped ? "انقر للعودة للوجه الإنجليزي" : "انقر لرؤية الترجمة والمثال"}
              </div>
            </div>

            {/* Flashcard Next / Mastery buttons */}
            <div className="flex items-center justify-between gap-3">
              <button
                onClick={() => {
                  handleToggleMastery(currentFlashcard.vocabId, false);
                  setIsFlipped(false);
                  if (cardIndex < favorites.length - 1) setCardIndex((p) => p + 1);
                }}
                className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition"
              >
                تحتاج مراجعة أخرى ↻
              </button>

              <button
                onClick={() => {
                  handleToggleMastery(currentFlashcard.vocabId, true);
                  setIsFlipped(false);
                  if (cardIndex < favorites.length - 1) setCardIndex((p) => p + 1);
                }}
                className="flex-1 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/20 transition"
              >
                أتقنت هذه الكلمة ✓
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
