"use client";

import React, { useState } from "react";
import { AudioButton } from "@/components/AudioButton";
import { LevelBadge } from "@/components/LevelBadge";
import { playEnglishText, playSoundEffect } from "@/lib/speech";
import {
  Volume2,
  Sparkles,
  Headphones,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Award,
  HelpCircle,
  Mic,
  Zap,
} from "lucide-react";

interface ListeningExercise {
  id: number;
  level: string;
  audioText: string;
  sentenceWithBlank: string;
  correctWord: string;
  translationAr: string;
  options: string[];
}

const listeningExercises: ListeningExercise[] = [
  {
    id: 1,
    level: "A1",
    audioText: "I drink hot coffee every morning.",
    sentenceWithBlank: "I drink hot ______ every morning.",
    correctWord: "coffee",
    translationAr: "أنا أشرب القهوة الساخنة كل صباح.",
    options: ["tea", "coffee", "water", "juice"],
  },
  {
    id: 2,
    level: "A1",
    audioText: "She is reading an interesting book.",
    sentenceWithBlank: "She is ______ an interesting book.",
    correctWord: "reading",
    translationAr: "هي تقرأ كتاباً ممتعاً.",
    options: ["writing", "reading", "buying", "eating"],
  },
  {
    id: 3,
    level: "A2",
    audioText: "We arrived at the airport two hours early.",
    sentenceWithBlank: "We arrived at the ______ two hours early.",
    correctWord: "airport",
    translationAr: "وصلنا إلى المطار قبل ساعتين.",
    options: ["station", "airport", "hotel", "office"],
  },
  {
    id: 4,
    level: "B1",
    audioText: "Practice English every day to improve your skills.",
    sentenceWithBlank: "Practice English every day to ______ your skills.",
    correctWord: "improve",
    translationAr: "مارس الإنجليزية كل يوم لتحسين مهاراتك.",
    options: ["improve", "forget", "change", "lose"],
  },
  {
    id: 5,
    level: "B2",
    audioText: "You will achieve great success with patience.",
    sentenceWithBlank: "You will ______ great success with patience.",
    correctWord: "achieve",
    translationAr: "ستحقق نجاحاً باهراً بالصبر.",
    options: ["achieve", "destroy", "reject", "prevent"],
  },
];

export default function ListeningPage() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedWord, setSelectedWord] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);

  const currentEx = listeningExercises[currentIndex];

  const handlePlayAudio = (rate: number = 0.85) => {
    playEnglishText(currentEx.audioText, rate);
  };

  const handleSelectOption = (word: string) => {
    if (feedback !== null) return;

    setSelectedWord(word);
    const isCorrect = word.toLowerCase() === currentEx.correctWord.toLowerCase();

    if (isCorrect) {
      playSoundEffect("correct");
      setFeedback("correct");
      setScore((prev) => prev + 1);
    } else {
      playSoundEffect("wrong");
      setFeedback("wrong");
    }

    setTimeout(() => {
      setFeedback(null);
      setSelectedWord(null);
      if (currentIndex < listeningExercises.length - 1) {
        setCurrentIndex((prev) => prev + 1);
      } else {
        setCompleted(true);
        playSoundEffect("fanfare");
      }
    }, 1800);
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setScore(0);
    setCompleted(false);
    setSelectedWord(null);
    setFeedback(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-semibold">
            <Headphones className="w-3.5 h-3.5" />
            <span>معمل الاستماع والإملاء الصوتي</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
            تدريبات الاستماع وفهم الكلام المنطوق
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto">
            درّب أذنك على تمييز الكلمات الإنجليزية بدقة وسرعات متعددة، واختر الكلمة المفقودة لإكمال الجملة.
          </p>
        </div>

        {!completed ? (
          <div className="space-y-6">
            {/* Exercise Header */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-300">
                  التمرين {currentIndex + 1} من {listeningExercises.length}
                </span>
                <LevelBadge level={currentEx.level} size="sm" />
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                  الدرجة: {score} 🌟
                </span>
              </div>
            </div>

            {/* Exercise Audio Player Card */}
            <div className="p-8 rounded-3xl bg-gradient-to-br from-indigo-950/60 via-slate-900 to-slate-900 border border-indigo-500/30 shadow-2xl text-center space-y-6">
              <div className="w-16 h-16 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mx-auto">
                <Volume2 className="w-8 h-8 animate-pulse" />
              </div>

              <div>
                <p className="text-xs text-slate-400 mb-2">استمع إلى الجملة بتركيز:</p>
                <div className="flex items-center justify-center gap-3">
                  <button
                    onClick={() => handlePlayAudio(0.85)}
                    className="px-6 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 inline-flex items-center gap-2 transition"
                  >
                    <Volume2 className="w-5 h-5" />
                    <span>تشغيل الصوت (طبيعي)</span>
                  </button>

                  <button
                    onClick={() => handlePlayAudio(0.55)}
                    className="px-5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-sm border border-slate-700 inline-flex items-center gap-1.5 transition"
                  >
                    <span>بطيء للمبتدئين 🐢</span>
                  </button>
                </div>
              </div>

              {/* Blank Sentence */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
                <p className="text-xl sm:text-2xl font-bold text-white en-ltr">
                  {currentEx.sentenceWithBlank}
                </p>
                <p className="text-xs text-slate-400 mt-2">{currentEx.translationAr}</p>
              </div>

              {/* Options */}
              <div>
                <p className="text-xs font-semibold text-slate-400 mb-3">
                  اختر الكلمة التي سمعتها في الفراغ:
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {currentEx.options.map((opt) => {
                    const isSelected = selectedWord === opt;
                    const isCorrect = opt.toLowerCase() === currentEx.correctWord.toLowerCase();

                    let btnClass = "bg-slate-900 hover:bg-slate-800 text-white border-slate-800";
                    if (feedback && isSelected) {
                      btnClass = isCorrect
                        ? "bg-emerald-600 text-white border-emerald-400 ring-2 ring-emerald-400"
                        : "bg-rose-600 text-white border-rose-400 ring-2 ring-rose-400";
                    }

                    return (
                      <button
                        key={opt}
                        onClick={() => handleSelectOption(opt)}
                        disabled={feedback !== null}
                        className={`p-4 rounded-2xl text-base font-bold en-ltr border transition transform active:scale-95 cursor-pointer ${btnClass}`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>

              {feedback && (
                <div
                  className={`p-3.5 rounded-2xl text-xs font-bold animate-in fade-in duration-200 ${
                    feedback === "correct"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                  }`}
                >
                  {feedback === "correct"
                    ? `🎉 أحسنت! الكلمة الصحيحة هي "${currentEx.correctWord}"`
                    : `❌ إجابة غير صحيحة. الكلمة الصحيحة هي "${currentEx.correctWord}"`}
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Completion Screen */
          <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 text-center space-y-6 shadow-2xl animate-in fade-in">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <Award className="w-8 h-8" />
            </div>

            <h2 className="text-3xl font-extrabold text-white">أكملت تدريب الاستماع بنجاح!</h2>
            <p className="text-sm text-slate-300">
              حصلت على {score} من أصل {listeningExercises.length} إجابات صحيحة.
            </p>

            <button
              onClick={handleRestart}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs inline-flex items-center gap-2 transition"
            >
              <RotateCcw className="w-4 h-4" />
              <span>إعادة التدريب</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
