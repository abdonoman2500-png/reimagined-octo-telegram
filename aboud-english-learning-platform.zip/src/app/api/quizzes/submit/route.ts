import { NextResponse } from "next/server";
import { db } from "@/db";
import { quizzes, quizAttempts, users, certificates } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    const body = await request.json();
    const { quizId, answers, placementLevel } = body;

    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, Number(quizId))).limit(1);

    if (!quiz) {
      return NextResponse.json({ error: "الاختبار غير موجود" }, { status: 404 });
    }

    const questions = JSON.parse(quiz.questionsJson);
    let correctCount = 0;
    const feedback: Array<{
      questionId: number;
      isCorrect: boolean;
      userAnswer: number | string;
      correctAnswer: number | string;
      explanationAr: string;
    }> = [];

    questions.forEach((q: { id: number; correctIndex: number; explanationAr: string }, idx: number) => {
      const userAnswer = answers[idx] !== undefined ? answers[idx] : null;
      const isCorrect = userAnswer === q.correctIndex;
      if (isCorrect) correctCount++;

      feedback.push({
        questionId: q.id || idx + 1,
        isCorrect,
        userAnswer,
        correctAnswer: q.correctIndex,
        explanationAr: q.explanationAr || "الإجابة الصحيحة موضحة أعلاه.",
      });
    });

    const scorePercentage = Math.round((correctCount / questions.length) * 100);
    const passed = scorePercentage >= quiz.passScore;

    let certificateGenerated = null;

    if (currentUser) {
      // Record quiz attempt
      await db.insert(quizAttempts).values({
        userId: currentUser.id,
        quizId: quiz.id,
        score: scorePercentage,
        totalQuestions: questions.length,
        passed,
        answersJson: JSON.stringify(feedback),
      });

      // Update XP & level if applicable
      const xpToAdd = passed ? quiz.xpReward : Math.round(quiz.xpReward / 4);
      let updatedLevel = currentUser.currentLevel;

      if (quiz.category === "placement" && placementLevel) {
        updatedLevel = placementLevel;
      }

      await db
        .update(users)
        .set({
          xp: currentUser.xp + xpToAdd,
          currentLevel: updatedLevel,
          lastActiveDate: new Date(),
        })
        .where(eq(users.id, currentUser.id));

      // Issue certificate if it's a placement or unit exam with high passing score
      if (passed && (quiz.category === "placement" || quiz.category === "unit_exam" || scorePercentage >= 80)) {
        const certNumber = `ABOUD-${Date.now().toString().slice(-6)}-${quiz.levelCode}`;
        const [cert] = await db
          .insert(certificates)
          .values({
            certificateNumber: certNumber,
            userId: currentUser.id,
            levelCode: quiz.levelCode,
            studentName: currentUser.name,
            score: scorePercentage,
          })
          .returning();
        certificateGenerated = cert;
      }
    }

    return NextResponse.json({
      success: true,
      score: scorePercentage,
      correctCount,
      totalQuestions: questions.length,
      passed,
      feedback,
      certificate: certificateGenerated,
      xpGained: passed ? quiz.xpReward : 10,
    });
  } catch (error) {
    console.error("Submit quiz error:", error);
    return NextResponse.json({ error: "فشل تصحيح الاختبار" }, { status: 500 });
  }
}
