import { NextResponse } from "next/server";
import { db } from "@/db";
import { quizzes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { seedDatabase } from "@/db/seed";

export async function GET(request: Request) {
  try {
    await seedDatabase();

    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const level = searchParams.get("level");

    let allQuizzes = await db.select().from(quizzes);

    if (category && category !== "all") {
      allQuizzes = allQuizzes.filter((q) => q.category === category);
    }
    if (level && level !== "all") {
      allQuizzes = allQuizzes.filter((q) => q.levelCode === level);
    }

    return NextResponse.json({ quizzes: allQuizzes });
  } catch (error) {
    console.error("Quizzes error:", error);
    return NextResponse.json({ error: "فشل تحميل الاختبارات" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || (currentUser.role !== "admin" && currentUser.role !== "teacher")) {
      return NextResponse.json({ error: "غير مصرح لك بإنشاء اختبارات" }, { status: 403 });
    }

    const body = await request.json();
    const { titleAr, titleEn, levelCode, category, passScore, timeLimitMinutes, xpReward, questionsJson } = body;

    const [newQuiz] = await db
      .insert(quizzes)
      .values({
        titleAr,
        titleEn,
        levelCode,
        category: category || "grammar",
        passScore: Number(passScore) || 70,
        timeLimitMinutes: Number(timeLimitMinutes) || 15,
        xpReward: Number(xpReward) || 50,
        questionsJson: typeof questionsJson === "string" ? questionsJson : JSON.stringify(questionsJson),
      })
      .returning();

    return NextResponse.json({ success: true, quiz: newQuiz });
  } catch (error) {
    console.error("Create quiz error:", error);
    return NextResponse.json({ error: "فشل إنشاء الاختبار" }, { status: 500 });
  }
}
