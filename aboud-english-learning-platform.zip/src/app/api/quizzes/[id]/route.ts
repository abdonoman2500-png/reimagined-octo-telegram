import { NextResponse } from "next/server";
import { db } from "@/db";
import { quizzes } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const quizId = parseInt(id, 10);

    if (isNaN(quizId)) {
      return NextResponse.json({ error: "معرف الاختبار غير صالح" }, { status: 400 });
    }

    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, quizId)).limit(1);

    if (!quiz) {
      return NextResponse.json({ error: "الاختبار غير موجود" }, { status: 404 });
    }

    return NextResponse.json({ quiz });
  } catch (error) {
    console.error("Quiz fetch error:", error);
    return NextResponse.json({ error: "فشل تحميل الاختبار" }, { status: 500 });
  }
}
