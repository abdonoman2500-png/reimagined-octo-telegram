import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    }

    const allUsers = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        role: users.role,
        currentLevel: users.currentLevel,
        xp: users.xp,
        streakDays: users.streakDays,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(desc(users.createdAt));

    return NextResponse.json({ users: allUsers });
  } catch (error) {
    console.error("Admin users error:", error);
    return NextResponse.json({ error: "فشل تحميل المستخدمين" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    }

    const { userId, role, currentLevel } = await request.json();

    const [updated] = await db
      .update(users)
      .set({
        ...(role && { role }),
        ...(currentLevel && { currentLevel }),
        updatedAt: new Date(),
      })
      .where(eq(users.id, Number(userId)))
      .returning();

    return NextResponse.json({ success: true, user: updated });
  } catch (error) {
    console.error("Admin user update error:", error);
    return NextResponse.json({ error: "فشل تحديث المستخدم" }, { status: 500 });
  }
}
