import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createToken } from "@/lib/auth";
import { seedDatabase } from "@/db/seed";

export async function POST(request: Request) {
  try {
    // Ensure db is seeded first
    await seedDatabase();

    const { role } = await request.json(); // 'student' | 'teacher' | 'admin'

    const targetEmail =
      role === "admin"
        ? "admin@aboud-english.com"
        : role === "teacher"
        ? "teacher@aboud-english.com"
        : "student@aboud-english.com";

    const [user] = await db.select().from(users).where(eq(users.email, targetEmail)).limit(1);

    if (!user) {
      return NextResponse.json({ error: "المستخدم التجريبي غير موجود" }, { status: 404 });
    }

    const sessionPayload = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role as "student" | "teacher" | "admin",
      currentLevel: user.currentLevel,
      xp: user.xp,
      streakDays: user.streakDays,
    };

    const token = createToken(sessionPayload);

    const response = NextResponse.json({
      success: true,
      user: sessionPayload,
      message: `تم تسجيل الدخول بصلاحية ${user.name}`,
    });

    response.cookies.set("auth_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
      path: "/",
    });

    return response;
  } catch (error) {
    console.error("Quick login error:", error);
    return NextResponse.json({ error: "فشل الدخول السريع" }, { status: 500 });
  }
}
