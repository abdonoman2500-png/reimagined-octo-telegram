import { NextResponse } from "next/server";
import { db } from "@/db";
import { conversations } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { seedDatabase } from "@/db/seed";

export async function GET(request: Request) {
  try {
    await seedDatabase();

    const { searchParams } = new URL(request.url);
    const level = searchParams.get("level");
    const scenario = searchParams.get("scenario");

    let items = await db.select().from(conversations).orderBy(asc(conversations.orderIndex));

    if (level && level !== "all") {
      items = items.filter((c) => c.levelCode === level);
    }
    if (scenario && scenario !== "all") {
      items = items.filter((c) => c.scenario === scenario);
    }

    return NextResponse.json({ conversations: items });
  } catch (error) {
    console.error("Conversations error:", error);
    return NextResponse.json({ error: "فشل تحميل المحادثات" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || (currentUser.role !== "admin" && currentUser.role !== "teacher")) {
      return NextResponse.json({ error: "غير مصرح لك بإضافة محادثات" }, { status: 403 });
    }

    const body = await request.json();
    const { titleAr, titleEn, scenario, levelCode, dialogueJson, grammarNotesAr } = body;

    const [newConv] = await db
      .insert(conversations)
      .values({
        titleAr,
        titleEn,
        scenario,
        levelCode,
        dialogueJson: typeof dialogueJson === "string" ? dialogueJson : JSON.stringify(dialogueJson),
        grammarNotesAr: grammarNotesAr || "",
      })
      .returning();

    return NextResponse.json({ success: true, conversation: newConv });
  } catch (error) {
    console.error("Create conversation error:", error);
    return NextResponse.json({ error: "فشل إضافة المحادثة" }, { status: 500 });
  }
}
