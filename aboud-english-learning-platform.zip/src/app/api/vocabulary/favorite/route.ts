import { NextResponse } from "next/server";
import { db } from "@/db";
import { userFavorites, vocabulary } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ favorites: [] });
    }

    const favoritesList = await db
      .select({
        id: userFavorites.id,
        vocabId: userFavorites.vocabId,
        mastered: userFavorites.mastered,
        createdAt: userFavorites.createdAt,
        word: vocabulary.word,
        phonetic: vocabulary.phonetic,
        partOfSpeech: vocabulary.partOfSpeech,
        translationAr: vocabulary.translationAr,
        levelCode: vocabulary.levelCode,
        category: vocabulary.category,
        exampleEn: vocabulary.exampleEn,
        exampleAr: vocabulary.exampleAr,
      })
      .from(userFavorites)
      .innerJoin(vocabulary, eq(userFavorites.vocabId, vocabulary.id))
      .where(eq(userFavorites.userId, currentUser.id));

    return NextResponse.json({ favorites: favoritesList });
  } catch (error) {
    console.error("Favorites fetch error:", error);
    return NextResponse.json({ error: "فشل تحميل الكلمات المفضلة" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "يرجى تسجيل الدخول لحفظ الكلمات" }, { status: 401 });
    }

    const { vocabId } = await request.json();
    if (!vocabId) {
      return NextResponse.json({ error: "معرف الكلمة مطلوب" }, { status: 400 });
    }

    const [existing] = await db
      .select()
      .from(userFavorites)
      .where(and(eq(userFavorites.userId, currentUser.id), eq(userFavorites.vocabId, Number(vocabId))))
      .limit(1);

    if (existing) {
      // Remove from favorites
      await db
        .delete(userFavorites)
        .where(and(eq(userFavorites.userId, currentUser.id), eq(userFavorites.vocabId, Number(vocabId))));

      return NextResponse.json({ success: true, isFavorite: false, message: "تمت إزالة الكلمة من المفضلة" });
    } else {
      // Add to favorites
      await db.insert(userFavorites).values({
        userId: currentUser.id,
        vocabId: Number(vocabId),
        mastered: false,
      });

      return NextResponse.json({ success: true, isFavorite: true, message: "تمت إضافة الكلمة إلى المفضلة والمراجعة" });
    }
  } catch (error) {
    console.error("Toggle favorite error:", error);
    return NextResponse.json({ error: "فشل تحديث المفضلة" }, { status: 500 });
  }
}

// Toggle or update mastery
export async function PUT(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "يرجى تسجيل الدخول" }, { status: 401 });
    }

    const { vocabId, mastered } = await request.json();

    await db
      .update(userFavorites)
      .set({ mastered: Boolean(mastered) })
      .where(and(eq(userFavorites.userId, currentUser.id), eq(userFavorites.vocabId, Number(vocabId))));

    return NextResponse.json({ success: true, mastered });
  } catch (error) {
    console.error("Update mastery error:", error);
    return NextResponse.json({ error: "فشل تحديث حالة الإتقان" }, { status: 500 });
  }
}
