import { NextResponse } from "next/server";
import { db } from "@/db";
import { vocabulary, userFavorites } from "@/db/schema";
import { eq, ilike, or, and, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { seedDatabase } from "@/db/seed";

export async function GET(request: Request) {
  try {
    await seedDatabase();

    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search")?.trim();
    const level = searchParams.get("level");
    const category = searchParams.get("category");

    const currentUser = await getCurrentUser();

    let allWords = await db.select().from(vocabulary);

    if (search) {
      const lower = search.toLowerCase();
      allWords = allWords.filter(
        (w) =>
          w.word.toLowerCase().includes(lower) ||
          w.translationAr.includes(search) ||
          (w.exampleEn && w.exampleEn.toLowerCase().includes(lower))
      );
    }

    if (level && level !== "all") {
      allWords = allWords.filter((w) => w.levelCode === level);
    }

    if (category && category !== "all") {
      allWords = allWords.filter((w) => w.category === category);
    }

    // Check favorite status for current user
    let favoriteVocabIds = new Set<number>();
    let masteredVocabIds = new Set<number>();

    if (currentUser) {
      const favs = await db
        .select()
        .from(userFavorites)
        .where(eq(userFavorites.userId, currentUser.id));

      favs.forEach((f) => {
        favoriteVocabIds.add(f.vocabId);
        if (f.mastered) masteredVocabIds.add(f.vocabId);
      });
    }

    const wordsWithFavorites = allWords.map((w) => ({
      ...w,
      isFavorite: favoriteVocabIds.has(w.id),
      isMastered: masteredVocabIds.has(w.id),
    }));

    return NextResponse.json({ vocabulary: wordsWithFavorites });
  } catch (error) {
    console.error("Vocabulary error:", error);
    return NextResponse.json({ error: "فشل تحميل المفردات" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || (currentUser.role !== "admin" && currentUser.role !== "teacher")) {
      return NextResponse.json({ error: "غير مصرح لك بإضافة كلمات" }, { status: 403 });
    }

    const body = await request.json();
    const { word, phonetic, partOfSpeech, translationAr, levelCode, category, exampleEn, exampleAr } = body;

    if (!word || !translationAr || !levelCode || !category) {
      return NextResponse.json({ error: "بيانات الكلمة غير مكتملة" }, { status: 400 });
    }

    const [newVocab] = await db
      .insert(vocabulary)
      .values({
        word: word.trim(),
        phonetic: phonetic || "",
        partOfSpeech: partOfSpeech || "noun",
        translationAr: translationAr.trim(),
        levelCode,
        category,
        exampleEn: exampleEn || "",
        exampleAr: exampleAr || "",
      })
      .returning();

    return NextResponse.json({ success: true, vocabulary: newVocab });
  } catch (error) {
    console.error("Add vocabulary error:", error);
    return NextResponse.json({ error: "فشل إضافة الكلمة" }, { status: 500 });
  }
}
