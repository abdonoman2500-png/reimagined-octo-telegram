"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { LevelBadge } from "@/components/LevelBadge";
import {
  Award,
  Sparkles,
  CheckCircle2,
  Lock,
  Unlock,
  Flame,
  Star,
  Trophy,
  BookOpen,
  Calendar,
  Clock,
  ShieldCheck,
} from "lucide-react";

export default function ProgressPage() {
  const { user } = useAuth();
  const [progressData, setProgressData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchProgress() {
      try {
        const res = await fetch("/api/progress");
        const data = await res.json();
        setProgressData(data);
      } catch (err) {
        console.error("Fetch progress failed", err);
      } finally {
        setLoading(false);
      }
    }
    fetchProgress();
  }, []);

  const cefrLevels = [
    { code: "Pre-A1", title: "المستوى التمهيدي (الحروف والأصوات)", minXp: 0 },
    { code: "A1", title: "المبتدئ (الضمائر والروتين والمطعم)", minXp: 300 },
    { code: "A2", title: "فوق المبتدئ (الماضي والمستقبل والسفر)", minXp: 800 },
    { code: "B1", title: "المتوسط (المضارع التام والعمل)", minXp: 1500 },
    { code: "B2", title: "فوق المتوسط (الجمل الشرطية والمبني للمجهول)", minXp: 2500 },
    { code: "C1", title: "المتقدم (التعبيرات الاصطلاحية والأمثال)", minXp: 4000 },
    { code: "C2", title: "الإتقان التام والطلاقة الشاملة", minXp: 6000 },
  ];

  const badges = [
    {
      id: "first-step",
      name: "أول خطوة 🚀",
      description: "التسجيل وبدء أول درس في المنصة",
      unlocked: true,
    },
    {
      id: "streak-warrior",
      name: "حارس الالتزام 🔥",
      description: "مواصلة التعلم لعدة أيام متتالية",
      unlocked: (user?.streakDays || 1) >= 3,
    },
    {
      id: "vocab-collector",
      name: "جامع الكلمات 📚",
      description: "حفظ 5 كلمات في المفضلة",
      unlocked: (progressData?.savedWordsCount || 0) >= 3,
    },
    {
      id: "quiz-champion",
      name: "بطل الاختبارات 🏆",
      description: "اجتياز اختبار تحديد المستوى أو اختبار وحدة",
      unlocked: (progressData?.quizzesTaken || 0) >= 1,
    },
    {
      id: "master-ear",
      name: "أذن موسيقية 🎧",
      description: "إكمال تدريبات الاستماع والنطق",
      unlocked: true,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-10">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
            <Trophy className="w-3.5 h-3.5" />
            <span>سجل الإنجازات والتقدم الأكاديمي</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
            رحلتك نحو الطلاقة في الإنجليزية
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            تتبّع تقدمك عبر مستويات CEFR والأوسمة التي حققتها واختباراتك السابقة.
          </p>
        </div>

        {/* CEFR Level Map */}
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <h2 className="text-xl font-bold text-white">خريطة مستويات CEFR</h2>
            <span className="text-xs text-indigo-400 font-semibold">
              المستوى الحالي للطالب: {user?.currentLevel || "Pre-A1"}
            </span>
          </div>

          <div className="space-y-4">
            {cefrLevels.map((lvl, idx) => {
              const isCurrent = user?.currentLevel === lvl.code;
              const isPassed = (user?.xp || 0) >= lvl.minXp;

              return (
                <div
                  key={lvl.code}
                  className={`p-5 rounded-2xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                    isCurrent
                      ? "bg-indigo-950/60 border-indigo-500/60 ring-2 ring-indigo-500/30"
                      : isPassed
                      ? "bg-slate-900/80 border-slate-800"
                      : "bg-slate-950/40 border-slate-900 opacity-60"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                        isCurrent
                          ? "bg-indigo-600 text-white"
                          : isPassed
                          ? "bg-emerald-600/20 text-emerald-400 border border-emerald-500/30"
                          : "bg-slate-800 text-slate-500"
                      }`}
                    >
                      {isPassed ? <CheckCircle2 className="w-5 h-5" /> : idx + 1}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <LevelBadge level={lvl.code} size="sm" />
                        <h4 className="font-bold text-sm text-white">{lvl.title}</h4>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">النقاط المطلوبة: {lvl.minXp} XP</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {isCurrent ? (
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                        مستواك الحالي 🎯
                      </span>
                    ) : isPassed ? (
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        مكتمل ✓
                      </span>
                    ) : (
                      <span className="text-xs text-slate-500 flex items-center gap-1">
                        <Lock className="w-3.5 h-3.5" />
                        <span>مغلق</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Badges & Achievements Grid */}
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
          <h2 className="text-xl font-bold text-white">الأوسمة والإنجازات المكتسبة</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {badges.map((b) => (
              <div
                key={b.id}
                className={`p-5 rounded-2xl border transition flex items-start gap-3 ${
                  b.unlocked
                    ? "bg-slate-950/80 border-amber-500/30 shadow-lg shadow-amber-500/5"
                    : "bg-slate-950/30 border-slate-900 opacity-40"
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    b.unlocked
                      ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                      : "bg-slate-800 text-slate-500"
                  }`}
                >
                  <Star className="w-5 h-5 fill-current" />
                </div>

                <div>
                  <h4 className="font-bold text-sm text-white">{b.name}</h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">{b.description}</p>
                  <span
                    className={`inline-block mt-2 text-[10px] font-bold ${
                      b.unlocked ? "text-emerald-400" : "text-slate-500"
                    }`}
                  >
                    {b.unlocked ? "تم الحصول عليه 🌟" : "قيد الإنجاز ⏳"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quiz Attempts History */}
        {progressData?.recentQuizAttempts && progressData.recentQuizAttempts.length > 0 && (
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-4">
            <h2 className="text-xl font-bold text-white">سجل الاختبارات السابقة</h2>

            <div className="space-y-2">
              {progressData.recentQuizAttempts.map((attempt: any) => (
                <div
                  key={attempt.id}
                  className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="font-bold text-white">اختبار معرف #{attempt.quizId}</span>
                    <p className="text-slate-400 text-[11px] mt-0.5">
                      التاريخ: {new Date(attempt.completedAt).toLocaleDateString("ar-EG")}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <span
                      className={`font-bold px-2.5 py-1 rounded-full ${
                        attempt.passed
                          ? "bg-emerald-500/20 text-emerald-300"
                          : "bg-rose-500/20 text-rose-300"
                      }`}
                    >
                      الدرجة: {attempt.score}% {attempt.passed ? "✓ ناجح" : "✕ لم يجتز"}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
